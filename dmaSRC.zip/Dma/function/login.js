
const firebaseConfig = { databaseURL: "https://arthur-1a00f-default-rtdb.firebaseio.com/" };
firebase.initializeApp(firebaseConfig);
const db = firebase.database();
const ADM_KEY = "adm";

function entrar(){
  const key = document.getElementById("loginKey").value.trim();
  if(key === ADM_KEY){
    window.location.href = "painel.html?adm=1";
  } else {
    db.ref("clients/"+key).get().then(snapshot=>{
      if(snapshot.exists()){
        const data = snapshot.val();
        const hoje = new Date();
        const validade = new Date(data.validade.split("/").reverse().join("-"));
        if(hoje <= validade){
          localStorage.setItem("clientKey", key);
          window.location.href = "painel.html";
        } else { alert("Key expirada!"); }
      } else { alert("Key inválida!"); }
    }).catch(err=>{ console.error(err); alert("Erro ao acessar Firebase"); });
  }
}