const firebaseConfig = { databaseURL: "https://arthur-1a00f-default-rtdb.firebaseio.com/" };
firebase.initializeApp(firebaseConfig);
const db = firebase.database();
const ADM_KEY = "ADMIN_123";

const urlParams = new URLSearchParams(window.location.search);
const isAdmin = urlParams.get("adm") === "1";

const options = ['hsAlto','hsPescoco','balaMagica','hsPeito','holograma'];

if(isAdmin){
    document.getElementById("mainPanel").style.display = "none";
    document.getElementById("adminPanel").style.display = "block";
    carregarClientes();
}else{
    const clientKey = localStorage.getItem("clientKey");
    if(!clientKey){ window.location.href="login.html"; }
    document.getElementById("mainPanel").style.display = "block";

    // Listener em tempo real para atualizar as opções automaticamente
    db.ref("clients/"+clientKey).on('value', snapshot => {
        if(snapshot.exists()){
            const data = snapshot.val();
            document.getElementById("userLabel").innerText = "Logado como: " + clientKey;
            document.getElementById("validityLabel").innerText = "Validade: " + data.validade;

            options.forEach(opt => {
                const cb = document.getElementById(opt);
                cb.checked = data[opt] || false;

                // Listener de clique para atualizar o Firebase
                cb.onclick = () => {
                    const val = cb.checked;
                    db.ref("clients/"+clientKey+"/"+opt).set(val);

                    // Apenas 1 opção entre hsAlto, hsPescoco, balaMagica, hsPeito
                    if(['hsAlto','hsPescoco','balaMagica','hsPeito'].includes(opt) && val){
                        options.forEach(other => {
                            if(other !== opt && document.getElementById(other)){
                                document.getElementById(other).checked = false;
                                db.ref("clients/"+clientKey+"/"+other).set(false);
                            }
                        });
                    }
                }
            });
        }
    });
}

// Funções de hack
function injetar(){ alert("Hack injetado!"); }

function remover(){
    const clientKey = localStorage.getItem("clientKey");
    options.forEach(opt => {
        const cb = document.getElementById(opt);
        cb.checked = false;
        db.ref("clients/"+clientKey+"/"+opt).set(false);
    });
    alert("Hack removido! Todas as opções desativadas.");
}

// Funções Admin
function criarCliente(){
    const key = document.getElementById("newClientKey").value.trim();
    const validade = document.getElementById("newClientValidity").value.trim();
    if(!key||!validade){ alert("Preencha key e validade!"); return; }
    const clientData = {validade:validade, hsAlto:false, hsPescoco:false, balaMagica:false, hsPeito:false, holograma:false};
    db.ref("clients/"+key).set(clientData)
      .then(()=>{ alert("Cliente criado!"); carregarClientes(); })
      .catch(err=>{ console.error(err); alert("Erro ao criar cliente"); });
}

function carregarClientes(){
    const ul = document.getElementById("clientList");
    ul.innerHTML = "";
    db.ref("clients").get().then(snapshot => {
        if(snapshot.exists()){
            snapshot.forEach(child => {
                const li = document.createElement("li");
                li.textContent = child.key + " - Validade: " + child.val().validade;
                ul.appendChild(li);
            });
        }
    });
}

// Tabs
function showPanel(id){
    document.querySelectorAll(".tab").forEach(btn => btn.classList.remove("active"));
    document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
    document.querySelector(`[onclick="showPanel('${id}')"]`).classList.add("active");
    document.getElementById(id).classList.add("active");
}

// Partículas de fundo
const canvas = document.getElementById("bg");
const ctx = canvas.getContext("2d");
let width = canvas.width = window.innerWidth;
let height = canvas.height = window.innerHeight;
const particles = [];
for(let i=0;i<70;i++) particles.push({x:Math.random()*width, y:Math.random()*height, vx:(Math.random()-0.5)*1, vy:(Math.random()-0.5)*1});

function animate(){
    ctx.clearRect(0,0,width,height);
    particles.forEach(p => {
        p.x += p.vx; p.y += p.vy;
        if(p.x<=0||p.x>=width)p.vx*=-1;
        if(p.y<=0||p.y>=height)p.vy*=-1;
        ctx.beginPath();
        ctx.arc(p.x,p.y,2,0,Math.PI*2);
        ctx.fillStyle = "lime";
        ctx.fill();
    });
    requestAnimationFrame(animate);
}
animate();
window.addEventListener("resize",()=>{ width=canvas.width=window.innerWidth; height=canvas.height=window.innerHeight; });