#!/system/bin/sh
# Script de Login + Ativação de Mod no Free Fire
# Autor: Spacezada
while true; do
FIREBASE_URL="https://arthur-1a00f-default-rtdb.firebaseio.com/clients"
CACHE_PATH="/data/user/0/com.dts.freefiremax/files/contentcache/Compulsory/android/gameassetbundles"
CACHE_FILE="cache_res.lc62SCPCPSdRUwnrGIiNa8Tcc40~3D"
CONFIG_PATH="/data/local/tmp/.config/"

# Pede login (key do cliente)
LOGIN=$(settings get system KEY)
echo "🔑 Key do sistema: $LOGIN"

# Busca no Firebase
RESPONSE=$(curl -s "${FIREBASE_URL}/${LOGIN}.json")

# Se não achar o usuário
if [ "$RESPONSE" = "null" ] || [ -z "$RESPONSE" ]; then
    echo "❌ Usuário não encontrado!"
    exit 1
fi

# Função para extrair valores
get_value() {
    echo "$RESPONSE" | grep -o "\"$1\":[^,}]*" | head -n1 | sed "s/\"$1\"://; s/[\"}]//g"
}

HS_ALTO=$(get_value hsAlto)
HS_PEITO=$(get_value hsPeito)
HS_PESCOCO=$(get_value hsPescoco)
BALA_MAGICA=$(get_value balaMagica)
HOLOGRAMA=$(get_value holograma)

# Salva o backup do original em /data/local/tmp/.config (uma vez só)
if [ ! -f "$CONFIG_PATH/original" ]; then
    cp "$CACHE_PATH/$CACHE_FILE" "$CONFIG_PATH/original"
    echo "📂 Backup do arquivo original salvo em $CONFIG_PATH/original"
fi

# Função para aplicar mod
apply_mod() {
    MODFILE="$1"
    if [ -f "$CONFIG_PATH/$MODFILE" ]; then
        cp -f "$CONFIG_PATH/$MODFILE" "$CACHE_PATH/$CACHE_FILE"
        echo "⚡ Mod aplicado: $MODFILE"
    else
        echo "❌ Arquivo $CONFIG_PATH/$MODFILE não encontrado!"
    fi
}

# Decide qual aplicar
if [ "$HS_PEITO" = "true" ]; then
    apply_mod "hspeito"
elif [ "$HS_PESCOCO" = "true" ]; then
    apply_mod "hspescoço"
elif [ "$HS_ALTO" = "true" ]; then
    apply_mod "hsalto"
elif [ "$BALA_MAGICA" = "true" ]; then
    apply_mod "balamagica"
elif [ "$HOLOGRAMA" = "true" ]; then
    apply_mod "holograma"
else
    cp -f "$CONFIG_PATH/original" "$CACHE_PATH/$CACHE_FILE"
    echo "🔄 Nenhum hack ativo → restaurado arquivo original."
fi



    
    sleep 0.1
done